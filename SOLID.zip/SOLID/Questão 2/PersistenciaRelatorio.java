public class PersistenciaRelatorio {

    /**
     * @param conteudo O conteúdo do relatório a ser salvo.
     */
    public void salvarEmArquivo(String conteudo) {
        System.out.println("Relatório salvo em arquivo .txt");
    }
}