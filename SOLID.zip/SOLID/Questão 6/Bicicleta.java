public class Bicicleta extends Veiculo {
    
    public void pedalar() {
        System.out.println("Bicicleta pedalando...");
    }
}