public abstract class Veiculo {
    Motorizado.java
    public void transportar() {
        System.out.println("Transportando...");
    }
}