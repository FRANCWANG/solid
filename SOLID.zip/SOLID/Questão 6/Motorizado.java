public interface Motorizado {
    void acelerar();
}