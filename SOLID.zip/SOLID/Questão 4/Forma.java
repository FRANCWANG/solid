public interface Forma {
    double calcularArea();
}