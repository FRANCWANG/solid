public class CalculadoraArea {

    public double calcularArea(Forma forma) {

        return forma.calcularArea();
    }
}