public class UsuarioRepository {
    
    public void cadastrar(Usuario usuario) {
        System.out.println("Usuário cadastrado: " + usuario.getNome());
    }
}