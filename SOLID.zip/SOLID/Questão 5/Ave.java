public abstract class Ave {
    public void botarOvo() {
        System.out.println("Botando ovo...");
    }

    public void comer() {
        System.out.println("Ave comendo...");
    }
}