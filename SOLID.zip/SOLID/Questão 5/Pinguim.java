public class Pinguim extends Ave {
    
    public void nadar() {
        System.out.println("Pinguim nadando...");
    }

    @Override
    public void comer() {
        System.out.println("Pinguim comendo peixe...");
    }
}