public interface AveVoadora {
    void voar();
}